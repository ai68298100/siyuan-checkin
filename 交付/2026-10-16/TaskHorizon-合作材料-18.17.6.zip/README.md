# 小驴打卡 × Task Horizon 合作材料包

日期：2026-10-16。提供端版本：18.17.6；API v5。安装包源码 tag：`v18.17.6`（`97d8ae94065f1bc16a343a4f6d4ce865dcc96548`）。

## 阅读顺序

1. [可直接转发回复稿](docs/taskhorizon-reply-2026-10-16.md)
2. [十项来件处理清单](docs/taskhorizon-provider-review-2026-10-16.md)
3. [验证记录](VALIDATION.md)
4. [合作设计](docs/checkin-taskhorizon-cooperation.md) 与 [API v5](docs/api-v5.md)
5. `docs/contracts/` 的兼容 manifest、draft 日历 fixture、Issue 草案及 incoming 原件

## 文件用途

- incoming 文件是对方 2026-10-12 来件的逐字节副本；其余文档是我方此次回应。
- `task-horizon-v1.json` 是已存在的 v4 兼容契约；`taskhorizon-calendar-consumer-v1.json` 仍是 draft。
- `contracts/siyuan-checkin-contract/` 是参考消费端自检工具；`examples/task-horizon-bridge/` 是 legacy v4 当日示例，不实现新的 v5 batch 合作接线。
- 完整源码测试在仓库中运行，命令见 VALIDATION。扩展文档链接可在 [仓库 main](https://github.com/ai68298100/siyuan-checkin) 查看。
- `SHA256SUMS.txt` 覆盖包内全部其它文件，可用于核对原件及材料完整性。

## 当前结论与下一步

W-01/02/04/05 已修复，C-04 已补边界验收；C-01/02/03、W-03 与 W-06 合作迁移仍待完成，两个 integrationContracts 均未声明。先完成日历批，再普通任务回写，最后双插件现场联调。single 无回执可能触发提供端自动恢复；新合作即使一条也应采用 v5 batch，由消费端拥有持久化队列。

[v18.17.6 安装包与发布说明](https://github.com/ai68298100/siyuan-checkin/releases/tag/v18.17.6)。此材料包用于合作沟通，未自动向对方发送。
